//! @file
//! This library implements all the functions needed ADC

//! Call this function to initialize the ADC
void conversion_init();

//! Call this function to return the ADC value
unsigned int conversion_value();
