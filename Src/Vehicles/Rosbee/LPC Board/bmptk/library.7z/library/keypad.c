#include "LPC11xx.h"
#include "timer.h"
#include "ports.h"

// Keypad 4*3!!!
int read_one_key(int row, int column){
	pin_configure_as_input(1,0);
	pin_configure_as_input(1,1);
	pin_configure_as_input(1,2);
	pin_configure_as_input(1,3);
	pin_configure_as_input(1,4);
	pin_configure_as_input(1,5);
	pin_configure_as_input(1,8);
	pin_configure_as_output(1, column);
	pin_set(1, column, 0);
	// make the one column output and low
	delay(5);
	// wait 5 ms
	if(pin_get(1,row)){
		return 1;
	}
	return 0;
	// check whether the one row is low
	// if so return 1
	
}

char keypad_read() {
	//config_pins();
	if( read_one_key( 0, 4)){ return '1'; }
	if( read_one_key( 0, 5)){ return '2'; }
	if( read_one_key( 0, 8)){ return '3'; }
	if( read_one_key( 1, 4)){ return '4'; }
	if( read_one_key( 1, 5)){ return '5'; }
	if( read_one_key( 1, 8)){ return '6'; }
	if( read_one_key( 2, 4)){ return '7'; }
	if( read_one_key( 2, 5)){ return '8'; }
	if( read_one_key( 2, 8)){ return '9'; }
	if( read_one_key( 3, 4)){ return '*'; }
	if( read_one_key( 3, 5)){ return '0'; }
	if( read_one_key( 3, 8)){ return '#'; }
	else {return 'n';}
}