//! @file
//! This library implements all the functions needed for IO

//! Call this function to configure a pin as input
void pin_configure_as_input( int port, int pin );

//! Call this function to configure a pin as output
void pin_configure_as_output( int port, int pin );

//! Call this function to send data to a output pin
void pin_set( int port, int pin, unsigned char x );

//! Call this function to get data from a input pin
unsigned char pin_get( int port, int pin );