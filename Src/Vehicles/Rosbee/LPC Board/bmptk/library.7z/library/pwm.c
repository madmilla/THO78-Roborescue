#include "LPC11xx.h"
#include "pwm.h"

void pwm_config() {
 LPC_SYSCON->SYSAHBCLKCTRL |= (1 << 10);  // enable clock for CT32B1
 LPC_SYSCON->SYSAHBCLKCTRL |= (1 << 16);  // enable IOCON

 //set pin to PWM function mode
 LPC_IOCON->R_PIO1_1 &= ~(7);
 LPC_IOCON->R_PIO1_1 |= 3;

 LPC_TMR32B1->MCR |= (1 << 10);

 //install en start timer
 LPC_TMR32B1->CTCR = 0;                // use AHB clock
 LPC_TMR32B1->PR   = 0;                  // 12 MHz -> 1 count/usec
 LPC_TMR32B1->TC   = 0;                   // start at 0
 LPC_TMR32B1->TCR  = 0x01;                // enable the timer

 //port forward pin to PWM function
 LPC_TMR32B1->PWMC |= 1;
 LPC_TMR32B1->MR3 = 100;
 //LPC_TMR32B1->EMR &= ~(3 << 4);
 LPC_TMR32B1->EMR /*|*/= (1 << 4);

 LPC_TMR32B1->MR0 = 50;
}

void setPWM(unsigned int timeHigh, unsigned int totalTime) {
	LPC_TMR32B1->MR0 = timeHigh; //set the time the pin must be set high, of the totalTime
	LPC_TMR32B1->MR3 = totalTime; //set the total time Frequent of they cycles
	LPC_TMR32B1->TC   = 0;    //reset, because if the count is above totalTime we must wait until a carry
}

/* Function to change timer value, not needed for normal PWM mode */
void pwm_setPR(unsigned int prValue){
 LPC_TMR32B1->PR = prValue;
}
