//! @file
//! This library implements all the functions needed ADC

//! Call this function to initialize and configure PWM
void pwm_config();

//! Call this function to return set the PWM
void setPWM(unsigned int timeHigh, unsigned int totalTime);

//! Useless function nowadays
void pwm_setPR(unsigned int prValue);