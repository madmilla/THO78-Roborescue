#include "servo.h"
#include "timer.h"
#include "LPC11xx.h"

void servo_init(int port, int pin) {
	if (port == 0) {
	LPC_GPIO0->DIR = LPC_GPIO0->DIR | (1 << pin);
	LPC_GPIO0->DATA = LPC_GPIO0->DATA &~ (1 << pin);
	}
	else if (port == 1) {
	LPC_GPIO1->DIR = LPC_GPIO1->DIR | (1 << pin);
	LPC_GPIO1->DATA = LPC_GPIO1->DATA &~ (1 << pin);
	}
}

void servo_low(void) {
   LPC_GPIO1->DATA = LPC_GPIO1->DATA & ~ 0x10;
}

void servo_high(void) {
   LPC_GPIO1->DATA = LPC_GPIO1->DATA | 0x10;;
}

void servo_pulse(int port, int pin, int position) {
	await(now() + length);
}