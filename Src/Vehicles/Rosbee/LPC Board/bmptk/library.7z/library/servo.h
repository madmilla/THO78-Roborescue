//! @file
//! This library implements all the functions needed to control a servo

//! Call this function to initialize the timer

void servo_init(port, pin);

void servo_pulse(port, pin, position);