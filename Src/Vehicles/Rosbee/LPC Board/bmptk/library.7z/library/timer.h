//! @file
//! This library implements all the functions needed for the timer

//! Call this function to initialize the timer
void timer_init(void);

//! Call this function to get the current time since the timer
//! was started
unsigned int now();

//! Call this function to wait for the given time
void await( unsigned int t );

//! Call this function to delay for the given time
void delay(unsigned int microseconds);

void delayExt(unsigned int milliseconds);
